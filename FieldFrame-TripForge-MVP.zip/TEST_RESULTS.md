# Test results — TripForge MVP

## Test 1 — Same-day trip
**Input:** fictional Science Discovery Center visit, 2026-11-12 through 2026-11-12, Class 1, school bus, required fields filled.
**Expected:** validation passes; status says ready for staff review; print/save PDF action enabled.
**Result:** PASS in the JavaScript logic harness. Status became “Validation passed — staff review required”; PDF action was enabled. Sample output: `test-results/01-same-day-trip.pdf`.

## Test 2 — Valid overnight trip
**Input:** fictional Regional Ecology Field Study, 2026-11-12 through 2026-11-13, Class 2, approved lodging provided, required fields filled.
**Expected:** validation passes with an overnight staff-review warning; print/save PDF action enabled.
**Result:** PASS in the JavaScript logic harness. Overnight review warning appeared and PDF action was enabled. Sample output: `test-results/02-overnight-trip.pdf`.

## Test 3 — Incomplete / blocked trip
**Input:** fictional request with end date before start date and required fields missing.
**Expected:** validation fails with actionable messages; PDF action remains disabled.
**Result:** PASS in the JavaScript logic harness. Missing fields and the reversed date range were reported; PDF action remained disabled. Sample output: `test-results/03-incomplete-trip-blocked.pdf`.

## Additional checks / known limits
- JavaScript syntax check passed with Node.js.
- Hazard Class 4 is blocked by the browser validation logic.
- Hazard Class 3 triggers a staff-review / possible-insurance warning.
- Overnight requests require lodging.
- PDF sample artifacts were generated with ReportLab and contain synthetic data. The `*-preview.png` files are raster previews of those PDFs, not screenshots of the live website.
- Full interactive Chromium testing was blocked by this execution environment. Before submission, open `index.html` in your browser, click each demo card, and take screenshots of the actual website states; also test the Print / Save PDF button.
- The browser PDF flow uses the print dialog; select “Save as PDF”. Popup permissions may be needed.
- No production data, login, Google Sheets sync, persistent storage, or official district workflow is implemented.
