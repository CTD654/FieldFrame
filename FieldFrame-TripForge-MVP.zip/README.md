# FieldFrame / TripForge MVP

A privacy-first static demo for reviewing trip-level requests, validating a few high-level rules, and printing a trip summary to PDF.

## Run
Open `index.html` in a modern browser. No build step or server is required. For best browser print-to-PDF support, use a desktop browser and allow the print dialog.

## Included
- `index.html` — responsive form, fictional demo directory, validation, and print-to-PDF flow
- `clean_web_export.csv` — two synthetic example records; not copied from the source workbook
- `CLEAN_FIELDS_AND_BEFORE_AFTER.md` — retained/excluded fields and rationale
- `TEST_RESULTS.md` — test scenarios and expected outcomes
- `test-results/` — sample PDFs for same-day, overnight, and blocked/incomplete cases

## Important limitations
- This is an MVP demo, not an official CCSD approval system.
- It does not connect to Google Sheets, submit forms, save records, or provide authentication/authorization.
- Validation is a basic safety check, not a substitute for district policy, official forms, or staff review.
- Class 3 raises a staff-review warning; Class 4 is blocked.
- Never add student names, student IDs, family contacts, medical details, signatures, or other sensitive data to the public demo.
- The supplied raw response workbook contained malformed test entries and sensitive contact/account columns, so it was not copied into this repository or the site package.
- Original official PDF templates were reviewed for workflow context but are not bundled because they contain real staff/contact and trip-letter content. Use current authorized originals through district-approved channels.

## Test
See `TEST_RESULTS.md`. The three required scenarios were checked against the validation rules. The PDF samples are synthetic test artifacts and do not represent approved travel.
