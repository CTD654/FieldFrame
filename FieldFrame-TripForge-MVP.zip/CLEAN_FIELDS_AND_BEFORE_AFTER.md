# Clean-field list and before/after note

## Kept in the public demo export
- `trip_title` — short purpose/title
- `start_date`, `end_date` — dates used for same-day/overnight logic
- `departure_time`, `estimated_return_time` — trip timing
- `starting_location`, `destination` — trip locations
- `transportation` — planned transport
- `hazard_class` — review routing / prohibited class check
- `lodging` — required for overnight trips
- `educational_value` — concise educational purpose
- `record_type` — explicitly labels every row as synthetic demo data

## Excluded from public export
- Email address and response timestamp
- Submitter first/last name
- Chaperone names/free-text list
- Bus number(s) and detailed capacity fields (not needed for this public demo)
- Raw error strings and arbitrary free-text test values
- The unused scratch sheet (`Sheet1`)
- Any student names, student IDs, parent/guardian contacts, health information, signatures, or permission-slip responses

## Before / after
**Before:** The provided workbook has 29 rows in `Form Responses 1`, including malformed or clearly artificial values (for example invalid dates, contradictory dates, a prohibited hazard class, free-text test strings) and contact/account fields. `Sheet1` is a scratch sheet with mostly empty or placeholder cells. The raw workbook is not safe or useful as a public directory.

**After:** The public export contains only the trip-level fields needed by this MVP and two explicitly synthetic examples. No original response row or personal contact field is carried into the public export. The raw workbook and original PDF templates are not bundled into the public website ZIP or demo app.
